import React = require('react')
import { View, Text } from 'react-native'

export default function Onboarding() {
  return (
    <View>
      <Text>onboarding</Text>
    </View>
  )
}