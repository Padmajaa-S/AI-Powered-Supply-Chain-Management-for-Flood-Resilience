import { Unmatched } from 'expo-router';
export default Unmatched;
