import home from "../assets/icons/home.png";
import profile from "../assets/icons/profile.png";


export default {
  home,
  profile,
};
